
# Include the license file
include LICENSE.txt

# Include the data files
recursive-include data *
